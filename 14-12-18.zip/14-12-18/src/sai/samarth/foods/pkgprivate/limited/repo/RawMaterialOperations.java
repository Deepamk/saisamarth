package sai.samarth.foods.pkgprivate.limited.repo;

import java.sql.ResultSet;
import java.sql.SQLException;

import sai.samarth.foods.pkgprivate.limited.DBConn;

public class RawMaterialOperations 
{
	
	private static final String tableName = "ItemRawMaterial";
	private static void createDateTable()
	{
		String createStmt = "create table " + tableName
				+ "( brand varchar(200), sizeInfo varchar(200),"
				+ "petCount integer, labelCount integer, boxesCount integer )";
		
		DBConn conn = new DBConn();
		conn.connect();
		conn.executeUpdate(createStmt);
		conn.close();
	}
	public static void addItemRawMaterial(String brand, String sizeInfo, int petCount, int labelCount, int boxesCount) throws SQLException
	{
		ItemRawMaterial itemRawMaterial = getItemRawMaterial(brand, sizeInfo);
		petCount += itemRawMaterial.getPetCount();
		labelCount += itemRawMaterial.getLabelCount();
		boxesCount += itemRawMaterial.getBoxesCount();
		
		updateItemRawMaterial(brand, sizeInfo, petCount, labelCount, boxesCount);
	}
	
	private static void createItemRawMaterial(String brand, String sizeInfo) throws SQLException
	{
		DBConn conn = new DBConn();
		conn.connect();
		
		String stmt = "insert into "+tableName+" values ('"+brand+"', '"+sizeInfo+"', 0, 0, 0)";
		
		conn.executeUpdate(stmt);
		conn.close();
	}
	
	private static void updateItemRawMaterial(String brand, String sizeInfo, int petCount, int labelCount, int boxesCount) throws SQLException
	{
		DBConn conn = new DBConn();
		conn.connect();
		
		String stmt = "update "+tableName+" set petCount = "+petCount+", labelCount = "+labelCount+", boxesCount = "+boxesCount+" where brand = '"+brand+"' and sizeInfo = '"+sizeInfo+"'";
		
		conn.executeUpdate(stmt);
		conn.close();
	}
	
	public static ItemRawMaterial getItemRawMaterial(String brand, String sizeInfo) throws SQLException
	{
		DBConn conn = new DBConn();
		conn.connect();
		if(!conn.isTableExists(tableName))
		{
			conn.close();
			createDateTable();
			createItemRawMaterial(brand, sizeInfo);
			return new ItemRawMaterial(brand, sizeInfo, 0, 0, 0);
		}
		
		conn.close();
		
		conn.connect();
		
		ResultSet rs = conn.executeQuery("select * from "+tableName + " where brand = '"+brand+"' and sizeInfo = '"+sizeInfo+"'");
		
		if(!rs.next())
		{
			conn.close();
			createItemRawMaterial(brand, sizeInfo);
			return new ItemRawMaterial(brand, sizeInfo, 0, 0, 0); 
		}
		
		int petCount = rs.getInt("petCount");
		int labelCount = rs.getInt("labelCount");
		int boxesCount = rs.getInt("boxesCount");
		
		conn.close();
		return new ItemRawMaterial(brand, sizeInfo, petCount, labelCount, boxesCount);
		
	}
	
	public static class ItemRawMaterial
	{
		private String brand;
		private String sizeInfo;
		private int petCount;
		private int labelCount;
		private int boxesCount;
		public ItemRawMaterial(String brand, String sizeInfo, int petCount, int labelCount, int boxesCount) {
			
			this.brand = brand;
			this.sizeInfo = sizeInfo;
			this.petCount = petCount;
			this.labelCount = labelCount;
			this.boxesCount = boxesCount;
		}
		public String getBrand() {
			return brand;
		}
		public String getSizeInfo() {
			return sizeInfo;
		}
		public int getPetCount() {
			return petCount;
		}
		public int getLabelCount() {
			return labelCount;
		}
		public int getBoxesCount() {
			return boxesCount;
		}
		
		
	}
}


