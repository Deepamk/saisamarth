/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sai.samarth.foods.pkgprivate.limited;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Deepam
 */
public class SAISAMARTHFOODSPRIVATELIMITED {
    
    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        DBConn dbConn = new DBConn();

		dbConn.connect();
		
		ResultSet rs = dbConn.executeQuery("select table_name from user_tables");
		while(rs.next())
		{
			System.out.println(rs.getString(1) );
		}
		rs.close();
		
		dbConn.close();

    }
}
