package sai.samarth.foods.pkgprivate.limited.repo;

import java.sql.ResultSet;
import java.sql.SQLException;

import sai.samarth.foods.pkgprivate.limited.DBConn;

public class RawCap 
{
	
	private static final String tableName = "ItemRawCap";
	private static void createDateTable()
	{
		String createStmt = "create table " + tableName
				+ "( brand varchar(200),"
				+ "capCount int )";
		
		DBConn conn = new DBConn();
		conn.connect();
		conn.executeUpdate(createStmt);
		conn.close();
	}
	public static void addItemRawCap(String brand, int capCount) throws SQLException
	{
		ItemRawCap ItemRawCap = getItemRawCap(brand);
		capCount += ItemRawCap.getcapCount();
		
		
		updateItemRawCap(brand, capCount);
	}
	
	private static void createItemRawCap(String brand) throws SQLException
	{
		DBConn conn = new DBConn();
		conn.connect();
		
		String stmt = "insert into "+tableName+" values ('"+brand+"', 0)";
		
		conn.executeUpdate(stmt);
		conn.close();
	}
	
	private static void updateItemRawCap(String brand,int capCount) throws SQLException
	{
		DBConn conn = new DBConn();
		conn.connect();
		
		String stmt = "update "+tableName+" set capCount = "+capCount+" where brand = '"+brand+"' ";
		
		conn.executeUpdate(stmt);
		conn.close();
	}
	
	public static ItemRawCap getItemRawCap(String brand) throws SQLException
	{
		DBConn conn = new DBConn();
		conn.connect();
		if(!conn.isTableExists(tableName))
		{
			conn.close();
			createDateTable();
			createItemRawCap(brand);
			return new ItemRawCap(brand, 0);
		}
		
		conn.close();
		
		conn.connect();
		
		ResultSet rs = conn.executeQuery("select * from "+tableName + " where brand = '"+brand+"' ");
		
		if(!rs.next())
		{
			conn.close();
			createItemRawCap(brand);
			return new ItemRawCap(brand, 0); 
		}
		
		int capCount = rs.getInt("capCount");
		
		
		conn.close();
		return new ItemRawCap(brand, capCount);
		
	}
	
	public static class ItemRawCap
	{
		private String brand;
		
		private int capCount;
		
		public ItemRawCap(String brand, int capCount) {
			
			this.brand = brand;
			
			this.capCount = capCount;
			
		}
		public String getBrand() {
			return brand;
		}
		
		public int getcapCount() {
			return capCount;
		}
		
		
		
	}
}


