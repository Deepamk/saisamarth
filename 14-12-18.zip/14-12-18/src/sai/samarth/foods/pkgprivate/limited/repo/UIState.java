package sai.samarth.foods.pkgprivate.limited.repo;

public class UIState 
{
	public static String currentBrand;
	public static String currentSize;
}
