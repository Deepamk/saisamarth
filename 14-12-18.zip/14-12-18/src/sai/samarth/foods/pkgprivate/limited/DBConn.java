/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sai.samarth.foods.pkgprivate.limited;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Deepam
 */
public class DBConn {
	static {

		String derbyHomeDirPath = "C:\\Inventory";

		System.setProperty("derby.system.home", derbyHomeDirPath);

		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block

		}

	}

	private Connection con;

	public void connect()  {
		try {
			con = DriverManager.getConnection("jdbc:derby:inventory;create=true");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ResultSet executeQuery(String query) {
		try {
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(query);

			return rs;

		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	public void executeUpdate(String query) {
		try {
			Statement stmt = con.createStatement();

			stmt.executeUpdate(query);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	public void close() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}
	
	public boolean isTableExists(String tableName)
	{
		try {
			Statement stmt = con.createStatement();

			stmt.executeQuery("select * from "+tableName);

			return true;
		}
		catch(Exception ex)
		{
			return false;
		}
	}
}
